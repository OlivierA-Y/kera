Kera experimental CPU inference bundle

Requires Python >=3.11, NumPy and Pillow. Run `python -m pip install -r requirements.txt`.
Run `python -m kera_ml.inference --help` from this directory for CLI arguments.
Pass --artifact deployment.json and actual RGB scan, middle-nail box, skin box and white-reference box.
Each box is [top,left,bottom,right], with exclusive bottom/right.
Python: from kera_ml.inference import Predictor
Predictor('deployment.json').predict_hemoglobin(image, nail_box, skin_box, reference_box)

This is an experimental research estimate, not clinically validated. Test MAE 16.78 g/L,
RMSE 22.22 g/L on 50 held-out study patients. For 11 patients below 120 g/L,
mean overestimation was 17.98 g/L. Results do not validate Kera Dock, Raspberry Pi
camera transfer, diagnosis, individual prediction confidence or longitudinal trends.
Actual Pi latency is untested. Collect paired Dock/laboratory data and independently
calibrate and validate before any caregiver use.

metadata.json includes full provenance, feature schema, versions and evaluation.
No training dataset, sklearn or PyTorch is needed for this selected linear artifact.
