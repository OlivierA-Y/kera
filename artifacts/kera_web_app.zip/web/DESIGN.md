# Kera camera workspace

Inventory: Kera wordmark, the nail silhouette, a middle-finger photograph, matching skin ROI, white paper reference, controlled light, live webcam view, 42 RGB descriptors, three trained MLP seeds, g/L output, no photo transmission, experimental research status.

Argument: show the real camera when permission is granted; help prepare a usable photo; identify the three regions the actual model requires; calculate the actual network output locally; explain what the result can and cannot establish.

Direction: Split stage, seed 682782689. Palette/type kept from the supplied logo. The logo's nail silhouette becomes the camera-off mark; the camera itself becomes the visual stage. The reading column changes with the real capture workflow. The live thing is capture → region selection → actual MLP estimate. No redraws. The marketing hero's stripe and unrelated atmospheric photographs were omitted because this is a functional camera app, not a marketing page; brand shape and real footage supply its identity.

Copy: “A closer look.” / “A nail photo. An experimental hemoglobin estimate.” / “Turn on camera” / “Choose the regions.” / “Your estimate.” The app does not imply a diagnosis or display an invented confidence percentage.

ROUND 1
Seen in one second: the camera stage and Kera nail silhouette.
Idea (one sentence): the middle-finger scan becomes the persistent stage while the adjacent column guides capture, annotation and interpretation.
Live thing: real webcam capture, photo annotation and trained neural inference.
Layout words by section: intro=typographic split / workspace=camera and reading column / result=photo and large estimate / footer=small research notes.
Scores: design 7 · usability 7 · creativity 7 · content 8 → overall 7.1
Caps applied: the general marketing rubric's four-picture floor is inapplicable to a webcam application; no stock imagery added.
Top three problems:
1. desktop-fold.jpg: camera height pushes shutter below a small laptop viewport. Cap desktop viewer height relative to viewport.
2. tablet-fold.jpg: instruction body is too small and soft. Use full ink at 16px.
3. mobile-result.jpg: programmatic focus outlines the entire result column. Keep control focus rings, remove the noninteractive result announcement outline, and screenshot after its short entrance ends.

ROUND 2
Seen in one second: a restrained camera workspace, with one clear camera action.
Idea (one sentence): the same real photo anchors preparation, marking and the measured output.
Live thing: tested camera and upload paths; no prerecorded or fabricated feed.
Layout words by section: intro=typographic split / workspace=wide stage with narrow guide / result=photo and numeral / phone=stacked capture then guidance.
Scores: design 8 · usability 8 · creativity 7 · content 9 → overall 7.9
Caps applied: marketing image-count/motion floors explicitly excepted; live media begins only with user permission. Minimal interface motion and no stock-image filler are deliberate.
Remaining limits: manual region selection is necessary because the trained model has no segmentation stage; physical webcam behavior depends on device/browser permission. No unsubstantiated usability claim is made. Full clinical validation is outside this interface task.

Assets: original user-provided Kera PNG; a small SVG nail silhouette derived in code from that brand shape for empty state/favicon. No found/generated imagery or sample content ships. Screenshots showing a study image exist only in ignored local reports, not deployment assets.

Browser checks: desktop, tablet and phone sizes; heading line counts, contrast, no overflow, no broken assets, no console exceptions. The taste inspector allows only few-pictures, no-footage and still-page, justified by the permission-gated product workflow. All other findings were corrected rather than suppressed.

Visual observation addition (October 2026): preserves the existing logo, monochrome palette, split capture stage and type scale. The optional section uses flat typographic rows for six findings, with no colored risk badges, scores or disease labels. Consent appears with the exact resized previews, including an optional side photo. Mobile dialog scrolls naturally; buttons retain visible focus. Reviewed desktop results and 390/768 px consent/results screenshots. Synthetic gray fixtures are test-only, never presented as live model output. Browser checks cover consent, side views, cancellation, stale requests, errors and overflow. No new decorative pictures or motion are appropriate for this clinical research tool.

Four-category skin and nail review: replaces morphology-only rows with skin cancer warning signs, fungal infection-like changes, eczema-like changes and psoriasis-like changes. Results use descriptive evidence, two non-diagnostic states and fixed clinical follow-up. There are no probability gauges, negative cancer results or reassurance badges. Desktop and mobile results were reviewed with synthetic fixtures. The optional second photo is another angle, rather than a mandatory side view. The numeric hemoglobin workflow retains its separate capture requirements.

Camera-first redesign: implements the approved desktop/mobile concept using the existing vanilla HTML/CSS and model controllers. Warm monochrome, supplied logo, two underlined modes, persistent photo, flat review rows and a fixed mobile Continue action. No illustrative nail image is shipped as a live feed. The initial camera state remains honestly off. The existing user guide and both photo setups are preserved. Review action/header/list dividers deliberately follow the approved mockup; the contributed guide's outlined close control remains a usable touch target. Tested 320/390 px phone widths, 768 px tablet and 1440 px desktop; mobile scrolling must bring every review category above the fixed action. Regression checks cover on-device inference, camera permission denial, no upload before consent, pre-consent second angle, tab switching/cancellation and mode-specific guide.

Mobile overlap correction: the fixed Continue panel could cover the review list, especially in a constrained browser viewport. It now follows categories/results in normal flow; the artificial 170 px bottom spacer is removed. Photo controls use two explicit grid rows instead of wrapping unpredictably. Browser verification at 320, 390 and 430 px checks no horizontal overflow and a 24 px gap between content and the action. Consent and synthetic results are verified with a local mock provider; no user photos are transmitted.

Touch marking and scan actions: an enlarged local-only modal supports two-corner taps, drag marking, 1–8× display zoom, separate photo panning, and button-based box movement/resizing. Original photo pixels remain the source of saved geometry. Save advances nail → skin → white; dismiss discards only the current draft. Phone scan actions mount outside animated ancestors so they remain fixed to the actual viewport; dynamic bottom clearance preserves access to the rest of the page. Browser checks at 320/390/430 px confirm saved dimensions, panning, zoom, all three regions, visible scan buttons, and a complete synthetic scan through Next scan and End scan now. No physical iPhone touch hardware is claimed to have been tested.
